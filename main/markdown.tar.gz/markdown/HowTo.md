## Moving screenshots pictures to *main* folder(of your project directory) and updating your *notes.md* file automatically with python

1. Open your notes.md file and start writing.
2. If you want to insert any screenshot (Which is stored by default in *Pictures* folder) to your *notes.md* file 
3. It can be done automatically by running `>>bash write.sh`
4. Make sure you copy and paste *writenotes.py* to *Picture* and edit line 14 in *write.sh* file accordingly

### Steps

`>>atom notes.md`

*click **PrtScr** or **Shift+PrtScr*** and click save.

`>> bash write.sh`

The screenshot is moved to *main* folder and *path is copied to notes.md file*


